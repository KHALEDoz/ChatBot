#!/usr/bin/env python3
"""
Test script to verify audio processing improvements
"""

import requests
import json
import base64

def test_audio_endpoints():
    """Test the audio processing endpoints"""
    base_url = "http://localhost:8080/api"
    
    print("🎤 Testing Audio Processing Endpoints")
    print("=" * 50)
    
    # Test 1: Speech-to-text with dummy data
    print("\n1. Testing speech-to-text endpoint...")
    try:
        response = requests.post(f"{base_url}/audio/speech-to-text",
            json={"audio_data": "dummy_base64_data"})
        
        if response.status_code == 400:
            print("✅ Speech-to-text endpoint accessible (expected error with dummy data)")
        else:
            print(f"⚠️  Unexpected response: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing speech-to-text: {e}")
    
    # Test 2: Text-to-speech
    print("\n2. Testing text-to-speech endpoint...")
    try:
        response = requests.post(f"{base_url}/audio/text-to-speech",
            json={"text": "Hello! This is a test of the improved audio processing."})
        
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                print("✅ Text-to-speech working correctly")
                print(f"   Audio data length: {len(data.get('audio_data', ''))} characters")
            else:
                print(f"❌ Text-to-speech failed: {data.get('error')}")
        else:
            print(f"❌ Text-to-speech failed with status: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing text-to-speech: {e}")
    
    # Test 3: Audio chat endpoint structure
    print("\n3. Testing audio chat endpoint...")
    try:
        response = requests.post(f"{base_url}/audio/chat",
            json={
                "audio_data": "dummy_base64_data",
                "conversation_id": "test_audio_fix"
            })
        
        if response.status_code == 400:
            print("✅ Audio chat endpoint accessible (expected error with dummy data)")
        else:
            print(f"⚠️  Unexpected response: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing audio chat: {e}")
    
    print("\n" + "=" * 50)
    print("🎯 Audio Processing Test Complete!")
    print("\n📝 Next Steps:")
    print("1. Open http://localhost:8080 in your browser")
    print("2. Click the microphone button to record")
    print("3. Speak clearly and wait for processing")
    print("4. Check the browser console for detailed logs")

if __name__ == "__main__":
    test_audio_endpoints() 