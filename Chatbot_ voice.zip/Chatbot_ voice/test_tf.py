import tensorflow as tf
tf.print("TensorFlow is working. Version:", tf.__version__)
