#!/usr/bin/env python3
"""
Comprehensive Test Script for AI Chatbot
Tests all features including text chat, audio processing, and LLM integration.
"""

import requests
import json
import time
import base64
import os
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8080"
API_BASE_URL = f"{BASE_URL}/api"

def print_test_header(test_name):
    """Print a formatted test header"""
    print(f"\n{'='*50}")
    print(f"🧪 Testing: {test_name}")
    print(f"{'='*50}")

def print_success(message):
    """Print a success message"""
    print(f"✅ {message}")

def print_error(message):
    """Print an error message"""
    print(f"❌ {message}")

def print_info(message):
    """Print an info message"""
    print(f"ℹ️  {message}")

def test_health_check():
    """Test the health check endpoint"""
    print_test_header("Health Check")
    
    try:
        response = requests.get(f"{API_BASE_URL}/health")
        if response.status_code == 200:
            data = response.json()
            print_success("Health check passed")
            print_info(f"Bot name: {data.get('bot_name')}")
            print_info(f"Status: {data.get('status')}")
            
            features = data.get('features', {})
            print_info("Available features:")
            for feature, available in features.items():
                status = "✅" if available else "❌"
                print(f"  {status} {feature}")
            
            return True
        else:
            print_error(f"Health check failed with status {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Health check error: {str(e)}")
        return False

def test_text_chat():
    """Test text-based chat functionality"""
    print_test_header("Text Chat")
    
    test_messages = [
        "Hello!",
        "How are you?",
        "Tell me a joke",
        "What time is it?",
        "Thank you!"
    ]
    
    conversation_id = f"test_{int(time.time())}"
    
    for i, message in enumerate(test_messages, 1):
        try:
            print(f"\n📝 Test {i}: '{message}'")
            
            response = requests.post(f"{API_BASE_URL}/chat", 
                json={
                    "message": message,
                    "conversation_id": conversation_id,
                    "use_cohere": False  # Use rule-based for testing
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                bot_response = data.get('response', '')
                print_success(f"Bot response: {bot_response}")
            else:
                print_error(f"Chat failed with status {response.status_code}")
                return False
                
        except Exception as e:
            print_error(f"Chat error: {str(e)}")
            return False
    
    return True

def test_text_to_speech():
    """Test text-to-speech functionality"""
    print_test_header("Text-to-Speech")
    
    test_text = "Hello! This is a test of the text to speech functionality. It should convert this text into spoken audio."
    
    try:
        print(f"📝 Converting text: '{test_text}'")
        
        response = requests.post(f"{API_BASE_URL}/audio/text-to-speech",
            json={"text": test_text}
        )
        
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                audio_data = data.get('audio_data', '')
                audio_file = data.get('audio_file', '')
                
                print_success("Text-to-speech successful")
                print_info(f"Audio file: {audio_file}")
                print_info(f"Audio data length: {len(audio_data)} characters")
                
                # Check if audio file exists
                if os.path.exists(audio_file):
                    print_success("Audio file created successfully")
                else:
                    print_error("Audio file not found")
                    return False
                
                return True
            else:
                print_error(f"Text-to-speech failed: {data.get('error')}")
                return False
        else:
            print_error(f"Text-to-speech failed with status {response.status_code}")
            return False
            
    except Exception as e:
        print_error(f"Text-to-speech error: {str(e)}")
        return False

def test_conversation_history():
    """Test conversation history functionality"""
    print_test_header("Conversation History")
    
    conversation_id = f"history_test_{int(time.time())}"
    
    try:
        # Send a few messages
        messages = ["Hello", "How are you?", "Goodbye"]
        
        for message in messages:
            response = requests.post(f"{API_BASE_URL}/chat",
                json={
                    "message": message,
                    "conversation_id": conversation_id,
                    "use_cohere": False
                }
            )
            if response.status_code != 200:
                print_error("Failed to send message for history test")
                return False
        
        # Get conversation history
        response = requests.get(f"{API_BASE_URL}/conversations/{conversation_id}")
        
        if response.status_code == 200:
            data = response.json()
            messages = data.get('messages', [])
            
            print_success(f"Retrieved conversation history")
            print_info(f"Number of messages: {len(messages)}")
            
            for msg in messages:
                sender = msg.get('sender', 'unknown')
                content = msg.get('message', '')
                print(f"  {sender}: {content}")
            
            return True
        else:
            print_error(f"Failed to get conversation history: {response.status_code}")
            return False
            
    except Exception as e:
        print_error(f"Conversation history error: {str(e)}")
        return False

def test_llm_integration():
    """Test LLM integration (if Cohere API key is available)"""
    print_test_header("LLM Integration")
    
    # Check if Cohere API key is available
    cohere_api_key = os.getenv('COHERE_API_KEY')
    
    if not cohere_api_key:
        print_info("No Cohere API key found - testing fallback mode")
        print_info("Set COHERE_API_KEY environment variable to test full LLM integration")
        
        # Test with fallback mode
        try:
            response = requests.post(f"{API_BASE_URL}/chat",
                json={
                    "message": "Hello! This is a test of the LLM integration.",
                    "conversation_id": "llm_test",
                    "use_cohere": False
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                print_success("Fallback mode working correctly")
                print_info(f"Response: {data.get('response')}")
                return True
            else:
                print_error("Fallback mode failed")
                return False
                
        except Exception as e:
            print_error(f"LLM test error: {str(e)}")
            return False
    else:
        print_info("Cohere API key found - testing full LLM integration")
        
        try:
            response = requests.post(f"{API_BASE_URL}/chat",
                json={
                    "message": "Hello! This is a test of the LLM integration.",
                    "conversation_id": "llm_test",
                    "use_cohere": True
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                print_success("LLM integration working correctly")
                print_info(f"Response: {data.get('response')}")
                return True
            else:
                print_error("LLM integration failed")
                return False
                
        except Exception as e:
            print_error(f"LLM test error: {str(e)}")
            return False

def test_audio_chat_pipeline():
    """Test the complete audio chat pipeline"""
    print_test_header("Audio Chat Pipeline")
    
    print_info("This test requires actual audio input")
    print_info("For automated testing, we'll test the individual components")
    
    # Test speech-to-text endpoint structure
    try:
        response = requests.post(f"{API_BASE_URL}/audio/speech-to-text",
            json={"audio_data": "dummy_data"}
        )
        
        # Should fail with invalid audio data, but endpoint should exist
        if response.status_code in [400, 500]:
            print_success("Speech-to-text endpoint accessible")
        else:
            print_error("Speech-to-text endpoint not working as expected")
            return False
            
    except Exception as e:
        print_error(f"Speech-to-text test error: {str(e)}")
        return False
    
    # Test audio chat endpoint structure
    try:
        response = requests.post(f"{API_BASE_URL}/audio/chat",
            json={
                "audio_data": "dummy_data",
                "conversation_id": "audio_test"
            }
        )
        
        # Should fail with invalid audio data, but endpoint should exist
        if response.status_code in [400, 500]:
            print_success("Audio chat endpoint accessible")
        else:
            print_error("Audio chat endpoint not working as expected")
            return False
            
    except Exception as e:
        print_error(f"Audio chat test error: {str(e)}")
        return False
    
    return True

def main():
    """Run all tests"""
    print("🤖 AI Chatbot - Comprehensive Feature Test")
    print("=" * 60)
    print(f"🕐 Test started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🌐 Testing against: {BASE_URL}")
    
    # Run all tests
    tests = [
        ("Health Check", test_health_check),
        ("Text Chat", test_text_chat),
        ("Text-to-Speech", test_text_to_speech),
        ("Conversation History", test_conversation_history),
        ("LLM Integration", test_llm_integration),
        ("Audio Chat Pipeline", test_audio_chat_pipeline)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print_error(f"Test '{test_name}' crashed: {str(e)}")
            results.append((test_name, False))
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status} - {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print_success("All tests passed! 🎉")
        return 0
    else:
        print_error(f"{total - passed} test(s) failed")
        return 1

if __name__ == "__main__":
    exit(main()) 