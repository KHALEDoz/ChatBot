#!/usr/bin/env python3
"""
Test script to verify auto-save functionality
"""

import requests
import json
import time

def test_auto_save_features():
    """Test the auto-save related features"""
    base_url = "http://localhost:8080/api"
    
    print("💾 Testing Auto-Save Features")
    print("=" * 50)
    
    # Test 1: Basic chat functionality
    print("\n1. Testing basic chat functionality...")
    try:
        response = requests.post(f"{base_url}/chat",
            json={
                "message": "Hello! This is a test message for auto-save.",
                "conversation_id": "auto_save_test"
            })
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Chat functionality working")
            print(f"   Response: {data.get('response', '')[:50]}...")
        else:
            print(f"❌ Chat failed with status: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing chat: {e}")
    
    # Test 2: Conversation history
    print("\n2. Testing conversation history...")
    try:
        response = requests.get(f"{base_url}/conversations/auto_save_test")
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Conversation history working")
            print(f"   Messages: {len(data.get('messages', []))}")
        else:
            print(f"❌ Conversation history failed with status: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing conversation history: {e}")
    
    # Test 3: Multiple messages
    print("\n3. Testing multiple messages...")
    test_messages = [
        "First test message",
        "Second test message", 
        "Third test message"
    ]
    
    for i, message in enumerate(test_messages, 1):
        try:
            response = requests.post(f"{base_url}/chat",
                json={
                    "message": message,
                    "conversation_id": "auto_save_test"
                })
            
            if response.status_code == 200:
                print(f"   ✅ Message {i} sent successfully")
            else:
                print(f"   ❌ Message {i} failed")
                
        except Exception as e:
            print(f"   ❌ Error sending message {i}: {e}")
    
    print("\n" + "=" * 50)
    print("🎯 Auto-Save Test Complete!")
    print("\n📝 Auto-Save Features:")
    print("✅ Automatic saving every 5 seconds")
    print("✅ Manual save button in header")
    print("✅ Conversation manager with folder icon")
    print("✅ New conversation button")
    print("✅ Load previous conversations")
    print("✅ Delete conversations")
    print("✅ Visual save/load indicators")
    print("✅ Conversation info display")
    
    print("\n🌐 Next Steps:")
    print("1. Open http://localhost:8080 in your browser")
    print("2. Send some messages")
    print("3. Check the save indicators (top-right)")
    print("4. Use the folder icon to manage conversations")
    print("5. Try creating new conversations")
    print("6. Refresh the page to see auto-restore")

if __name__ == "__main__":
    test_auto_save_features() 