# AI Chatbot

A modern, interactive chatbot built with Flask and a beautiful web interface. This chatbot features a responsive design, real-time messaging, and intelligent responses.

## Features

- 🤖 **Intelligent Responses**: Rule-based chatbot with contextual responses
- 🧠 **LLM Integration**: Cohere AI integration for advanced conversations
- 🎤 **Speech-to-Text**: Voice input with real-time transcription
- 🔊 **Text-to-Speech**: Audio responses with natural voice synthesis
- 💬 **Real-time Chat**: Instant messaging with typing indicators
- 🎨 **Beautiful UI**: Modern, responsive design with gradient backgrounds
- 📱 **Mobile Friendly**: Works perfectly on all devices
- ⚡ **Fast & Lightweight**: Built with Flask for optimal performance
- 🔄 **Conversation History**: Maintains chat history during sessions
- 🎯 **Quick Suggestions**: Pre-defined message suggestions for easy interaction

## Quick Start

### Prerequisites

- Python 3.7 or higher
- pip (Python package installer)

### Installation

1. **Clone or download the project files**

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables** (optional):
   ```bash
   # Copy the template and add your Cohere API key
   cp env_template.txt .env
   # Edit .env and add your COHERE_API_KEY
   ```

4. **Run the application**:
   ```bash
   python app.py
   # or use the launcher script
   ./start_chatbot.sh
   ```

5. **Open your browser** and go to:
   ```
   http://localhost:8080
   ```

## Usage

### Basic Interaction

The chatbot can respond to various types of messages:

- **Greetings**: "Hello", "Hi", "Hey"
- **Well-being**: "How are you?", "How do you do?"
- **Help**: "Help", "What can you do?"
- **Time**: "What time is it?", "What's the date?"
- **Entertainment**: "Tell me a joke", "Say something funny"
- **Weather**: "What's the weather like?"
- **Goodbyes**: "Bye", "Goodbye", "See you"

### Audio Features

- **Voice Input**: Click the microphone button to record your voice
- **Voice Output**: Bot responses are automatically converted to speech
- **Audio Playback**: Click the play button to hear responses again
- **Real-time Transcription**: See your spoken words converted to text instantly

### Features

- **Auto-resizing input**: The message input automatically adjusts to your text
- **Enter to send**: Press Enter to send messages (Shift+Enter for new lines)
- **Quick suggestions**: Click on suggestion chips for instant messages
- **Real-time responses**: See typing indicators while the bot responds
- **Message timestamps**: Each message shows when it was sent

## API Endpoints

The chatbot provides a RESTful API:

### Text Chat
- `GET /` - Main chat interface
- `POST /api/chat` - Send a message and get response
- `GET /api/conversations` - Get all conversations
- `GET /api/conversations/<id>` - Get specific conversation
- `DELETE /api/conversations/<id>` - Delete a conversation

### Audio Processing
- `POST /api/audio/speech-to-text` - Convert speech to text
- `POST /api/audio/text-to-speech` - Convert text to speech
- `POST /api/audio/chat` - Complete audio chat pipeline

### System
- `GET /api/health` - Health check endpoint

### Example API Usage

```bash
# Send a text message
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "conversation_id": "user123"}'

# Convert text to speech
curl -X POST http://localhost:8080/api/audio/text-to-speech \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello! This is a test."}'

# Complete audio chat (speech-to-text -> LLM -> text-to-speech)
curl -X POST http://localhost:8080/api/audio/chat \
  -H "Content-Type: application/json" \
  -d '{"audio_data": "base64_encoded_audio", "conversation_id": "user123"}'

# Get conversation history
curl http://localhost:8080/api/conversations/user123

# Health check
curl http://localhost:8080/api/health
```

## Customization

### Adding New Responses

To add new responses, edit the `get_response` method in `app.py`:

```python
def get_response(self, message, conversation_id):
    message = message.lower().strip()
    
    # Add your custom responses here
    if any(word in message for word in ['your_keyword']):
        return "Your custom response here!"
    
    # ... existing code ...
```

### Styling

The UI is styled with CSS in the HTML template. You can customize:

- Colors: Modify the gradient values in CSS
- Fonts: Change the font-family properties
- Layout: Adjust container dimensions and spacing
- Animations: Modify keyframe animations

### Integration with AI Services

To integrate with external AI services (like OpenAI), modify the `get_response` method:

```python
import openai

def get_response(self, message, conversation_id):
    # Call external AI service
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": message}]
    )
    return response.choices[0].message.content
```

## Project Structure

```
chatbot/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── README.md          # This file
├── test_tf.py         # TensorFlow test file
└── templates/
    └── index.html     # Chat interface template
```

## Technologies Used

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Custom CSS with gradients and animations
- **Icons**: Font Awesome
- **API**: RESTful API with JSON responses

## Development

### Running in Development Mode

```bash
python app.py
```

The app runs in debug mode by default, which enables:
- Auto-reload on code changes
- Detailed error messages
- Debug console

### Environment Variables

Create a `.env` file for environment-specific settings:

```env
PORT=5000
FLASK_ENV=development
```

## Deployment

### Production Deployment

For production deployment:

1. **Set environment variables**:
   ```bash
   export FLASK_ENV=production
   export PORT=8080
   ```

2. **Use a production WSGI server**:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:8080 app:app
   ```

3. **Set up a reverse proxy** (nginx recommended) for SSL and load balancing

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

If you encounter any issues or have questions:

1. Check the console for error messages
2. Verify all dependencies are installed
3. Ensure the Flask server is running
4. Check that the port 5000 is available

## Future Enhancements

- [ ] Database integration for persistent conversations
- [ ] User authentication and profiles
- [ ] File upload and sharing
- [ ] Voice message support
- [ ] Multi-language support
- [ ] Advanced AI integration
- [ ] Conversation analytics
- [ ] Custom bot personalities

---

**Enjoy chatting with your AI assistant! 🤖✨** 