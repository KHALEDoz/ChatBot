# 🎤 Voice Recording Troubleshooting Guide

## Common Issues and Solutions

### 1. "Sorry, I could not process your audio" Error

**Possible Causes:**
- Microphone permissions not granted
- Audio format not supported
- Network connectivity issues
- Speech recognition service unavailable

**Solutions:**

#### Check Microphone Permissions
1. **Chrome/Edge**: Click the microphone icon in the address bar
2. **Firefox**: Click the microphone icon in the address bar
3. **Safari**: Go to Safari > Preferences > Websites > Microphone
4. **Mobile**: Check Settings > Privacy & Security > Microphone

#### Browser Console Debugging
1. Open Developer Tools (F12)
2. Go to Console tab
3. Look for error messages when recording
4. Check for "🎤" prefixed messages

#### Test Microphone
1. Go to https://www.onlinemictest.com/
2. Test your microphone is working
3. Check audio levels are adequate

### 2. Audio Recording Not Starting

**Solutions:**
- Refresh the page
- Try a different browser
- Check if another app is using the microphone
- Restart your browser

### 3. Poor Speech Recognition

**Tips for Better Results:**
- **Speak Clearly**: Enunciate each word
- **Reduce Background Noise**: Find a quiet environment
- **Close to Microphone**: Keep microphone within 6-12 inches
- **Normal Pace**: Don't speak too fast or too slow
- **Complete Sentences**: Speak full thoughts rather than fragments

### 4. Browser Compatibility

**Supported Browsers:**
- ✅ Chrome 66+
- ✅ Firefox 60+
- ✅ Safari 11+
- ✅ Edge 79+

**Not Supported:**
- ❌ Internet Explorer
- ❌ Old mobile browsers

### 5. Network Issues

**Check:**
- Internet connection is stable
- No firewall blocking the connection
- Server is running (green dot in top-right)

### 6. Server-Side Issues

**If server shows red dot:**
1. Check if the Flask server is running
2. Restart the server: `python app.py`
3. Check terminal for error messages

## Testing Your Setup

### Quick Test
1. Open http://localhost:8080
2. Click the microphone button
3. Say "Hello, this is a test"
4. Wait for processing
5. Check browser console for logs

### Advanced Testing
Run the test script:
```bash
python test_audio_fix.py
```

## Debug Information

### Browser Console Messages
Look for these messages in the console:
- `🎤 Recording started...` - Recording initiated
- `🎤 Processing audio blob: X bytes` - Audio captured
- `🎤 Sending audio to server...` - Uploading to server
- `🎤 Server response: {...}` - Server response

### Server Logs
Check the terminal running `python app.py` for:
- Audio processing errors
- Speech recognition failures
- Network request logs

## Alternative Solutions

### If Voice Still Doesn't Work

1. **Use Text Input**: Type your messages instead
2. **Try Different Browser**: Switch to Chrome or Firefox
3. **Check Microphone Hardware**: Test with other applications
4. **Restart Everything**: Browser, server, and computer

### Manual Testing
Test the API directly:
```bash
# Test text-to-speech
curl -X POST http://localhost:8080/api/audio/text-to-speech \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, this is a test"}'

# Test speech-to-text (with dummy data)
curl -X POST http://localhost:8080/api/audio/speech-to-text \
  -H "Content-Type: application/json" \
  -d '{"audio_data": "dummy_data"}'
```

## Getting Help

If you're still having issues:

1. **Check the logs**: Look at browser console and server terminal
2. **Try the test script**: `python test_audio_fix.py`
3. **Verify setup**: Ensure all dependencies are installed
4. **Check permissions**: Microphone access is crucial

## Success Indicators

When voice recording is working correctly, you should see:
- ✅ Green status indicator in top-right
- ✅ Microphone button turns red when recording
- ✅ "Recording..." message appears
- ✅ Audio gets processed and transcribed
- ✅ Bot responds with both text and audio

---

**Remember**: Voice recognition works best with clear speech in a quiet environment! 🎤✨ 