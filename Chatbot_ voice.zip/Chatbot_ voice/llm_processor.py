import cohere
import os
from dotenv import load_dotenv
import json
from datetime import datetime

# Load environment variables
load_dotenv()

class LLMProcessor:
    def __init__(self):
        """Initialize Cohere client"""
        self.api_key = os.getenv('COHERE_API_KEY')
        if not self.api_key:
            print("⚠️  Warning: COHERE_API_KEY not found in environment variables")
            print("   You can set it in a .env file or as an environment variable")
            print("   Get your API key from: https://console.cohere.ai/")
        
        self.co = cohere.Client(self.api_key) if self.api_key else None
        
        # Conversation context
        self.conversation_history = {}
        
        # System prompt for the chatbot
        self.system_prompt = """You are a helpful and friendly AI assistant. You can help users with various tasks, answer questions, and engage in meaningful conversations. 

Your responses should be:
- Helpful and informative
- Conversational and friendly
- Concise but thorough
- Appropriate for all audiences

You can help with:
- General questions and information
- Problem-solving and advice
- Creative tasks and brainstorming
- Educational topics
- Casual conversation

Always be respectful, honest, and helpful."""
    
    def generate_response(self, message, conversation_id='default', use_cohere=True):
        """
        Generate a response using Cohere or fallback to rule-based responses
        
        Args:
            message: User's message
            conversation_id: Unique conversation identifier
            use_cohere: Whether to use Cohere API (falls back to rule-based if False or API unavailable)
            
        Returns:
            str: Generated response
        """
        if use_cohere and self.co:
            return self._generate_cohere_response(message, conversation_id)
        else:
            return self._generate_rule_based_response(message)
    
    def _generate_cohere_response(self, message, conversation_id):
        """Generate response using Cohere API"""
        try:
            # Get conversation history
            history = self.conversation_history.get(conversation_id, [])
            
            # Prepare messages for Cohere
            messages = []
            
            # Add system prompt
            messages.append({
                "role": "system",
                "content": self.system_prompt
            })
            
            # Add conversation history
            for msg in history[-10:]:  # Keep last 10 messages for context
                messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
            
            # Add current user message
            messages.append({
                "role": "user",
                "content": message
            })
            
            # Generate response using Cohere
            response = self.co.chat(
                message=message,
                preamble=self.system_prompt,
                conversation_id=conversation_id,
                temperature=0.7,
                max_tokens=150
            )
            
            # Extract response text
            response_text = response.text
            
            # Update conversation history
            if conversation_id not in self.conversation_history:
                self.conversation_history[conversation_id] = []
            
            self.conversation_history[conversation_id].append({
                "role": "user",
                "content": message,
                "timestamp": datetime.now().isoformat()
            })
            
            self.conversation_history[conversation_id].append({
                "role": "assistant",
                "content": response_text,
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep conversation history manageable
            if len(self.conversation_history[conversation_id]) > 20:
                self.conversation_history[conversation_id] = self.conversation_history[conversation_id][-20:]
            
            return response_text
            
        except Exception as e:
            print(f"Error with Cohere API: {str(e)}")
            # Fallback to rule-based response
            return self._generate_rule_based_response(message)
    
    def _generate_rule_based_response(self, message):
        """Generate response using rule-based logic (fallback)"""
        message = message.lower().strip()
        
        # Simple rule-based responses
        if any(word in message for word in ['hello', 'hi', 'hey']):
            return "Hello! I'm your AI assistant. How can I help you today?"
        
        elif any(word in message for word in ['how are you', 'how do you do']):
            return "I'm doing great, thank you for asking! I'm here and ready to help you with anything you need."
        
        elif any(word in message for word in ['bye', 'goodbye', 'see you']):
            return "Goodbye! It was nice chatting with you. Feel free to come back anytime!"
        
        elif any(word in message for word in ['help', 'what can you do']):
            return "I can help you with various tasks like answering questions, having conversations, providing information, and more. Just ask me anything!"
        
        elif any(word in message for word in ['weather', 'temperature']):
            return "I'd love to help you with weather information! However, I don't have access to real-time weather data right now. You might want to check a weather app or website."
        
        elif any(word in message for word in ['time', 'date']):
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return f"The current date and time is: {current_time}"
        
        elif any(word in message for word in ['joke', 'funny']):
            jokes = [
                "Why don't scientists trust atoms? Because they make up everything!",
                "Why did the scarecrow win an award? Because he was outstanding in his field!",
                "What do you call a fake noodle? An impasta!",
                "Why don't eggs tell jokes? They'd crack each other up!",
                "What do you call a bear with no teeth? A gummy bear!"
            ]
            import random
            return random.choice(jokes)
        
        elif any(word in message for word in ['thank', 'thanks']):
            return "You're very welcome! I'm happy to help. Is there anything else you'd like to know?"
        
        elif any(word in message for word in ['name', 'who are you']):
            return "I'm an AI assistant created to help you with various tasks and conversations. You can call me your AI helper!"
        
        elif any(word in message for word in ['music', 'song']):
            return "I can't play music directly, but I can help you find information about songs, artists, or music recommendations!"
        
        elif any(word in message for word in ['food', 'eat', 'hungry']):
            return "I can't eat, but I can help you find recipes, restaurant recommendations, or food-related information!"
        
        else:
            # Default response for unrecognized messages
            return "That's interesting! I'm here to help you with various tasks. Could you try asking me something specific, or maybe rephrase your question?"
    
    def get_conversation_history(self, conversation_id):
        """Get conversation history for a specific conversation"""
        return self.conversation_history.get(conversation_id, [])
    
    def clear_conversation_history(self, conversation_id=None):
        """Clear conversation history"""
        if conversation_id:
            if conversation_id in self.conversation_history:
                del self.conversation_history[conversation_id]
        else:
            self.conversation_history.clear()
    
    def test_cohere_connection(self):
        """Test Cohere API connection"""
        if not self.co:
            return {
                'success': False,
                'error': 'Cohere API key not configured',
                'message': 'Please set COHERE_API_KEY in your environment variables'
            }
        
        try:
            # Simple test request
            response = self.co.generate(
                prompt="Hello",
                max_tokens=10,
                temperature=0
            )
            return {
                'success': True,
                'message': 'Cohere API connection successful'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'message': 'Failed to connect to Cohere API'
            }

# Test function
def test_llm_processor():
    """Test the LLM processor functionality"""
    processor = LLMProcessor()
    
    print("🧠 LLM Processor Test")
    print("=" * 30)
    
    # Test Cohere connection
    print("Testing Cohere API connection...")
    connection_test = processor.test_cohere_connection()
    if connection_test['success']:
        print("✅ Cohere API connection successful")
    else:
        print(f"⚠️  Cohere API connection failed: {connection_test['message']}")
    
    # Test responses
    test_messages = [
        "Hello!",
        "How are you?",
        "Tell me a joke",
        "What time is it?",
        "Thank you!"
    ]
    
    print("\nTesting response generation...")
    for message in test_messages:
        response = processor.generate_response(message, "test_conversation")
        print(f"User: {message}")
        print(f"Bot: {response}")
        print("-" * 40)
    
    # Test conversation history
    print("\nTesting conversation history...")
    history = processor.get_conversation_history("test_conversation")
    print(f"Conversation history length: {len(history)}")
    
    print("✅ Test completed!")

if __name__ == "__main__":
    test_llm_processor() 